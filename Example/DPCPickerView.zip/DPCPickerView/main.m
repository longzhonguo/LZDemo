//
//  main.m
//  DPCPickerView
//
//  Created by 陈龙 on 10/14/2020.
//  Copyright (c) 2020 陈龙. All rights reserved.
//

@import UIKit;
#import "CLAppDelegate.h"

int main(int argc, char * argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([CLAppDelegate class]));
    }
}
