//
//  CLAppDelegate.h
//  DPCPickerView
//
//  Created by 陈龙 on 10/14/2020.
//  Copyright (c) 2020 陈龙. All rights reserved.
//

@import UIKit;

@interface CLAppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
